# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param
from azure.cli.core.commands.parameters import resource_group_name_type


def add_workspace_common_params(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the workspace.")


def load_workspace_params(self):
    with self.argument_context("ml workspace create") as c:
        add_common_params(c)
        add_override_param(c)
        c.argument("no_wait", help="Default wait, set this to not wait.")

    with self.argument_context("ml workspace list") as c:
        c.argument("resource_group_name", resource_group_name_type)
        add_workspace_common_params(c)

    with self.argument_context("ml workspace show") as c:
        add_common_params(c)
        add_workspace_common_params(c)

    with self.argument_context("ml workspace delete") as c:
        add_common_params(c)
        add_workspace_common_params(c)
        c.argument("all_resources", help="delete all dependent resources, defaults no.")
        c.argument("no_wait", help="Default wait, set this to not wait.")

    with self.argument_context("ml workspace list-keys") as c:
        add_common_params(c)
        add_workspace_common_params(c)

    with self.argument_context("ml workspace sync-keys") as c:
        add_common_params(c)
        add_workspace_common_params(c)

    with self.argument_context("ml workspace update") as c:
        add_common_params(c)
        add_workspace_common_params(c)
