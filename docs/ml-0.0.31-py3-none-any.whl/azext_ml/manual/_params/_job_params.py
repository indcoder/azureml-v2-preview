# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params, add_override_param


def add_job_common_params(c):
    c.argument("name", options_list=["--name", "-n"], type=str, help="Name of the job.")


def load_job_params(self):
    with self.argument_context("ml job create") as c:
        add_common_params(c)
        add_job_common_params(c)
        add_override_param(c)
        c.argument("file", options_list=["--file", "-f"], help="yaml file to generate code job from.")
        c.argument("save_as", options_list=["--save-as", "-a"], help="file to save code job to.")
        c.argument("stream", options_list=["--stream", "-s"], help="streams the job logs into the console.")
        c.argument("web", help="If successful, the CLI will try to show the created job in a web browser.")

    with self.argument_context("ml job list") as c:
        add_common_params(c)

    with self.argument_context("ml job show") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument("web", help="If successful, the CLI will try to show the job in a web browser.")

    with self.argument_context("ml job download") as c:
        add_common_params(c)
        add_job_common_params(c)
        c.argument(
            "outputs", options_list=["--outputs", "-u"], help="All files generated in the job including outputs."
        )
        c.argument(
            "download_path",
            options_list=["--download-path", "-p"],
            help="If not specified will be downloaded into the current dir.",
        )

    with self.argument_context("ml job stream") as c:
        add_common_params(c)
        add_job_common_params(c)
