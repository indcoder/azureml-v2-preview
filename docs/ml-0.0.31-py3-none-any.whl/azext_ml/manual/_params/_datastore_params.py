# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from ._common_params import add_common_params


def add_datastore_include_secrets_param(c):
    c.argument(
        "include_secrets",
        options_list=["--include-secrets", "-i"],
        action="store_true",
        help="when argument present, returns secrets for datastore",
    )


def load_datastore_params(self):
    with self.argument_context("ml datastore delete") as c:
        add_common_params(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="name of datastore to delete from workspace")

    with self.argument_context("ml datastore show") as c:
        add_common_params(c)
        add_datastore_include_secrets_param(c)
        c.argument("name", options_list=["--name", "-n"], type=str, help="name of datastore to detach from workspace")

    with self.argument_context("ml datastore list") as c:
        add_common_params(c)
        add_datastore_include_secrets_param(c)

    with self.argument_context("ml datastore create") as c:
        add_common_params(c)
        c.argument("file", options_list=["--file", "-f"], help="yaml definition of datastore")
        c.argument("name", options_list=["--name", "-n"], help="display name of datastore in workspace")
