# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_compute_help():
    helps[
        "ml compute"
    ] = """
        type: group
        short-summary: ml compute
    """
