# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from knack.help_files import helps


def get_data_help():
    helps[
        "ml data"
    ] = """
        type: group
        short-summary: ml data
    """
