# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from typing import Dict

from azure.ml import MLClient
from azure.identity import AzureCliCredential
from azure.cli.core.commands.client_factory import get_subscription_id
from .print_error import print_error_and_exit


def ml_environment_create(cmd, resource_group_name, workspace_name, file, environment_name=None, params_override=None):
    # TODO : Once EMS supports accepting a version will enable it
    # environment_version=None
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        return ml_client.environments.create_or_update(
            environment_name=environment_name, environment_version=None, file=file, params_override=params_override
        ).dump()

    except Exception as err:
        print_error_and_exit(str(err))


def ml_environment_show(cmd, resource_group_name, workspace_name, environment_name, environment_version=None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        if environment_version is None:
            return ml_client.environments.get_latest_version(environment_name=environment_name).dump()
        return ml_client.environments.get(
            environment_name=environment_name, environment_version=environment_version
        ).dump()
    except Exception as err:
        print_error_and_exit(str(err))


def ml_environment_list(cmd, resource_group_name, workspace_name):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )

    try:
        return ml_client.environments.list()
    except Exception as err:
        print_error_and_exit(str(err))


def _ml_environment_update(cmd, resource_group_name, workspace_name, parameters: Dict = None):
    subscription_id = get_subscription_id(cmd.cli_ctx)

    ml_client = MLClient(
        subscription_id=subscription_id,
        resource_group_name=resource_group_name,
        default_workspace_name=workspace_name,
        credential=AzureCliCredential(),
    )
    try:
        rest_obj = ml_client.environments._update(yaml_environment=parameters)
        return rest_obj.dump()
    except Exception as err:
        print_error_and_exit(str(err))
