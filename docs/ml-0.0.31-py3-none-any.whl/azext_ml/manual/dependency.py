# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------
from azext_ml.manual.version import VERSION

DEPENDENCIES = ["azure-ml=={version}".format(version=VERSION),
                "cryptography<=3.3.2"]
