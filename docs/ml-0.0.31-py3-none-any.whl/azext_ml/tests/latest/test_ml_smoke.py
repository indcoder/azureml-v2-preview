# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

import pytest

from azure.cli.core import MainCommandsLoader, AzCli
from azure.cli.core.commands import AzCliCommandInvoker, ExtensionCommandSource
from azure.cli.core.parser import AzCliCommandParser
from azure.cli.core._help import AzCliHelp, CliCommandHelpFile, ArgumentGroupRegistry
from azure.cli.testsdk import ScenarioTest
from io import StringIO
from typing import Any
from unittest.mock import patch


def get_extension_commands():

    cli_ctx = AzCli(
        cli_name="az",
        commands_loader_cls=MainCommandsLoader,
        invocation_cls=AzCliCommandInvoker,
        parser_cls=AzCliCommandParser,
        help_cls=AzCliHelp,
    )

    # 1. Create invoker and load command table.
    invoker = cli_ctx.invocation_cls(
        cli_ctx=cli_ctx,
        commands_loader_cls=cli_ctx.commands_loader_cls,
        parser_cls=cli_ctx.parser_cls,
        help_cls=cli_ctx.help_cls,
    )

    cmd_table = invoker.commands_loader.load_command_table(None)

    #   filter the command table to only get commands from extensions
    cmd_table = {k: v for k, v in cmd_table.items() if isinstance(v.command_source, ExtensionCommandSource)}
    print("FOUND {} command(s) from the extension.".format(len(cmd_table)))

    # return the actual commands
    return cmd_table.keys()


def check_successful_exit(exit: Any):
    assert exit.type == SystemExit
    assert exit.value.code == 0


def check_command_output(output: str, command: str):
    assert command in output
    assert "Arguments" in output


class MlSmokeTests(ScenarioTest):
    def test_all_commands_for_smoke(self) -> None:
        # Get all the commands
        commands = get_extension_commands()

        # Execute each cli command
        for command in commands:
            with pytest.raises(SystemExit) as exit, patch("sys.stdout", new=StringIO()) as fake_out:
                self.cmd(f"{command} --help")

            # Smoke check on output and exit code
            check_command_output(fake_out.getvalue(), command)
            check_successful_exit(exit)
