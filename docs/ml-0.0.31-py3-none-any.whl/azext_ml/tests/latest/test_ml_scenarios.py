# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Any
import pytest
from azure.cli.testsdk import ScenarioTest
import yaml
from pathlib import Path
from tempfile import TemporaryDirectory
from ..util import *


class MlTests(ScenarioTest):
    def __init__(self, method_name: Any) -> None:
        super().__init__(
            method_name,
            recording_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
            ],
            replay_processors=[
                MD5HeaderRemover(),
                ResourceGroupReplacer(),
                WorkspaceNameReplacer(),
                AzureBlobReplacer(),
            ],
        )
        self.kwargs.update(
            {
                "jobName": self.create_random_name(prefix="test-job-", length=24),
                "datasetName": self.create_random_name(prefix="test-dataset-", length=24),
                "modelName": self.create_random_name(prefix="test-model-", length=24),
                "environmentName": self.create_random_name(prefix="test-environment-", length=24),
                "onlineEndpointName": self.create_random_name(prefix="test-onl-endpt-", length=24),
                "batchEndpointName": self.create_random_name(prefix="test-bat-endpt-", length=24),
                "subscription": self.get_subscription_id(),
            }
        )

    def test_data(self) -> None:
        data_obj = self.cmd("az ml data upload --name {datasetName} --path tests/test_configs/python --version 1")
        data_obj = yaml.safe_load(data_obj.output)
        assert data_obj["name"] == self.kwargs.get("datasetName", None)
        assert "az-ml-artifacts/" in data_obj["file"]
        assert data_obj["version"] == 1
        assert "workspaceblobstore" in data_obj["datastore"]
        assert data_obj["file"].endswith("python")

        data_show_job = self.cmd("az ml data show --name {datasetName} --version 1")
        data_show_job = yaml.safe_load(data_show_job.output)
        assert_same(data_obj, data_show_job)

    def test_job(self) -> None:
        # TODO: Assumes there is a compute called testCompute, which may prevent a successful recording
        job_obj = self.cmd("az ml job create --file tests/test_configs/jobs/command_job_test.yml --name {jobName}")
        job_obj = yaml.safe_load(job_obj.output)
        assert job_obj["name"] == self.kwargs.get("jobName", None)
        assert "testCompute" in job_obj["compute"]["target"]
        assert "environments/AzureML-Minimal/versions/1" in job_obj["environment"]
        assert job_obj["experiment_name"] == "mfe-test1"
        assert job_obj["command"] == "pip freeze"

        job_show_obj = self.cmd("az ml job show --name {jobName}")
        job_show_obj = yaml.safe_load(job_show_obj.output)
        assert_same(job_obj, job_show_obj, filter=["status", "creation_context"])
        # TODO: why does creation_context differs in the output of creation and show?

        self.cmd("az ml job stream --name {jobName}")
        with TemporaryDirectory() as tmp_path:
            self.cmd("az ml job download --name {jobName} --download-path '" + tmp_path + "'")
            assert (Path(tmp_path) / self.kwargs.get("jobName", None)).is_dir()

    @pytest.mark.skip()
    def test_sweep_job(self) -> None:
        self.cmd("az ml job create --file tests/test_configs/sweep_job_test.yaml --name {jobName}")
        self.cmd("az ml job show --name {jobName}")

    def test_model(self) -> None:
        model_obj = self.cmd(
            "az ml model create --file tests/test_configs/model_full.yml --name {modelName} --set tags.abc=456"
        )
        model_obj = yaml.safe_load(model_obj.output)
        assert model_obj["name"] == self.kwargs.get("modelName", None)
        assert model_obj["description"] == "this is my test model"
        assert model_obj["environment"] == "azureml:AzureML-Minimal:1"
        assert "model.pkl" in model_obj["path"]
        assert model_obj["tags"]["abc"] == "456"
        assert model_obj["tags"]["foo"] == "bar"

        model_show_job = self.cmd("az ml model show --name {modelName} --version 3")
        model_show_job = yaml.safe_load(model_show_job.output)
        assert_same(model_obj, model_show_job)

    def test_model_without_yml(self) -> None:
        model_obj = self.cmd("az ml model create --name {modelName} --path tests/test_configs/model.pkl --version 1")
        model_obj = yaml.safe_load(model_obj.output)
        assert model_obj["name"] == self.kwargs.get("modelName", None)
        assert model_obj["environment"] == "azureml:AzureML-Minimal:1"
        assert "model.pkl" in model_obj["path"]

        model_show_job = self.cmd("az ml model show --name {modelName} --version 1")
        model_show_job = yaml.safe_load(model_show_job.output)
        assert_same(model_obj, model_show_job)

    def test_environment(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_conda.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert env_obj["version"] == 1
        assert "example-environment" in env_obj["conda_file"]
        assert "docker" not in env_obj
        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])

    def test_environment_with_docker(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_docker.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert env_obj["docker"]["image"] == "mcr.microsoft.com/azureml/base:0.2.2"
        assert "conda_file" not in env_obj
        assert env_obj["version"] == 1

        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])

    def test_environment_using_dockerfile(self) -> None:
        env_obj = self.cmd(
            "az ml environment create --file tests/test_configs/environment/environment_docker_file.yml --name {environmentName} --set version=1"
        )
        env_obj = yaml.safe_load(env_obj.output)
        assert env_obj["name"] == self.kwargs.get("environmentName", None)
        assert "ubuntu:16.04" in env_obj["docker"]["build"]["dockerfile"]
        assert "conda_file" not in env_obj
        assert env_obj["version"] == 1

        env_show_obj = self.cmd("az ml environment show --name {environmentName}")
        env_show_obj = yaml.safe_load(env_show_obj.output)
        assert_same(env_obj, env_show_obj, filter=["creation_context"])

    def test_workspace(self) -> None:
        # TODO: once the workspace and compute work are done, we will be using dynamic workspace e2e infras. Then we can test ws creation.
        ws_name = "sdk_vnext_cli"
        ws_obj = self.cmd(f"az ml workspace show --name {ws_name}")
        ws_obj = yaml.safe_load(ws_obj.output)
        ws_obj["name"] == ws_name
        ws_obj["location"] == "centraluseuap"

    """
    TODO: Running the endpoint tests will get the following error msg:

    E       AssertionError: You need to call 'result' or 'wait' on all LROPoller you have created

    Need to investigate how endpoint operation uses LROPoller
    """

    # def test_endpoint_creation(self) -> None:
    #     result = self.cmd(
    #         "az ml endpoint create --file tests/test_configs/online_endpoint_create_aks.yml --name {onlineEndpointName}"
    #     )
    #     if _is_poller(result):
    #         result.result()

    # def test_endpoint_show(self) -> None:
    #     self.cmd("az ml endpoint show --name {onlineEndpointName}")

    # def test_batch_endpoint(self) -> None:
    #     self.cmd("az ml endpoint create --file tests/test_configs/batch_endpoint.yaml --name {batchEndpointName}")

    # def test_batch_endpoint_show(self) -> None:
    #     self.cmd("az ml endpoint show --name {batchEndpointName}")
