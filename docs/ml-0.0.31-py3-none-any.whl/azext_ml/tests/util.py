# ---------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# ---------------------------------------------------------

from typing import Dict, List
from azure_devtools.scenario_tests import (
    RecordingProcessor,
)
from urllib.parse import urlparse
from itertools import product
import re


def assert_same(*yaml_objs: Dict, filter: List[str] = []):
    if len(yaml_objs) < 2:
        raise ValueError("the length of yaml object to compare should be at least 2")
    for yaml_obj, filter_val in product(yaml_objs, filter):
        yaml_obj.pop(filter_val)
    base_to_compare = yaml_objs[0]
    for obj in yaml_objs[1:]:
        assert obj == base_to_compare


class ResourceGroupReplacer(RecordingProcessor):
    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert "resourceGroups" in u.path

            u = u._replace(
                path=re.sub(r"resourceGroups/.+/provider", "resourceGroups/000000000000000/provider", u.path)
            )

            request.uri = u.geturl()
            return request
        except Exception:
            return request


class WorkspaceNameReplacer(RecordingProcessor):
    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            assert "/workspaces/" in u.path
            u = u._replace(path=re.sub(r"/workspaces/[^/]+", "/workspaces/000000000000000", u.path))
            request.uri = u.geturl()
            return request
        except Exception:
            return request


class MD5HeaderRemover(RecordingProcessor):
    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            request.headers.pop("content-md5")
            return request
        except Exception:
            return request


class AzureBlobReplacer(RecordingProcessor):
    """
    Replace https://storagea5jlura67u2una.blob.core.windows.net/azureml-blobstore-09911d39-adba-4943-950e-1c1540bf2711/az-ml-artifacts/7e05d06d-2462-446d-a683-61aa383be019/python/sample1.csv
    to https://xxxxxxxxxxxxxxxxxxxxxx.blob.core.windows.net/azureml-blobstore-00000000-0000-0000-0000-000000000000/az-ml-artifacts/00000000-0000-0000-0000-00000000000/python/sample1.csv
    """

    def process_request(self, request):  # pylint: disable=no-self-use
        try:
            u = urlparse(request.uri)
            storage_account, *rest = u.netloc.split(".")
            assert ".".join(rest) == "blob.core.windows.net"
            empty, blobstore, container, folder, *path = u.path.split("/")
            assert container == "az-ml-artifacts"
            u = u._replace(netloc="xxxxxxxxxxxxxxxxxxxxxx." + ".".join(rest))
            u = u._replace(
                path="/".join(
                    [
                        empty,
                        "azureml-blobstore-00000000-0000-0000-0000-000000000000",
                        container,
                        "00000000-0000-0000-0000-00000000000",
                    ]
                    + path
                )
            )
            request.uri = u.geturl()
            return request
        except Exception:
            return request
